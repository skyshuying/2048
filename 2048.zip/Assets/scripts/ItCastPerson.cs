﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItCastPerson : MonoBehaviour {

    // Use this for initialization
   
	public Sprite[] Persons = new Sprite[12];
	private SpriteRenderer sr1;
	private int level = 0;
    private object itcastHelper;

    void Start () {
		sr1 = GetComponent<SpriteRenderer>();
	}
	void UpdateLevel()
	{
		level ++;
		//修改当前对象的名称
		name = "p" + level;
		sr1.sprite = Persons[level];
        if (level > 11)
        {
            ItCaseHelper.IsWin = true;
        }
	}	
}
