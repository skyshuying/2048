﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateFg : MonoBehaviour {
	public GameObject Fg;
		// Use this for initialization
	void Start () {
		for (int i = 0;i < 4; i++)
		{
			for (int j = 0;j < 4; j++)
			{
				GameObject obj = Instantiate(Fg) as GameObject;
				obj.transform.position = new Vector3(
				-5.3f + i * 3f,
				3.6f - j * 2.5f, 
				0
				);
                Fg.name = "Fg" + i + "_" + j;
			}
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
