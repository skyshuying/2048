﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItCastMange : MonoBehaviour {
public GameObject Person;
public Texture2D Win;
private GameObject[,] PersonList = new GameObject[4,4];
private GameObject person;
private GameObject personBefore;
	// Use this for initialization
	void Start () {
		CreatePerson();
		CreatePerson();
	}
	//生成游戏对象
	void CreatePerson()
	{   //随机生成位置
	    int x1 = -1,y1 = -1;
		do{
			 x1=Random.Range(0,4);
			 y1=Random.Range(0,4);
		}while(PersonList[x1,y1]!=null);
	GameObject p = Instantiate(Person) as GameObject;
	p.name="p0";
	p.transform.position=new Vector3(
				-5.3f + x1 * 3f,
				3.6f - y1 * 2.5f, 
				-1
				);
	//记录当前位置存在了游戏对象
	PersonList[x1,y1] = p;
	}
	void Update()
	{
        if(ItCaseHelper.IsWin)
        {
            //如果胜利不再操作！
            return;
        }
		if(Input.GetKeyDown(KeyCode.UpArrow))
		{
			//对于第0行不需要移动
			for(int y = 1; y < 4;y++)
			{
				for(int x = 0; x < 4;x++)
				{
					person = PersonList[x,y];
					if(person == null)
					{
						//如果当前位置没有对象，则不需要进行任何操作
						continue;
					}
					//如果当前位置有对象，则执行以下代码
					//判断当前位置的前面是否有对象
					int destPos = -1;
					for(int y1 = y-1; y1 >= 0; y1--)
					{
						personBefore = PersonList[x,y1];
						if(personBefore!=null)
						{
							//如果有，则不再向前找
							if(person.name.Equals(personBefore.name))
							{
								//如果是相同的对象则合并，不再需要移动当前对象
								destPos=-1;
								Destroy(person);
								PersonList[x,y]=null;
								personBefore.SendMessage("UpdateLevel");
							}
							break;
						}else
						{
							destPos = y1;
							//如果没有则继续向前找
						}
					}
					if(destPos>-1)
					{
						//完成移动
						//1.更新矩阵信息
						PersonList[x,y] = null;
						PersonList[x,destPos] = person;
						//2.更改当前游戏对象的位置
						person.transform.position += new Vector3(0,(y-destPos)* 2.5f, 0);
					}
				}
			}
			CreatePerson();
		}else if(Input.GetKeyDown(KeyCode.DownArrow))
		{
			//第三行不需要移动，最下行。
			for(int y = 2; y >= 0; y--)
			{
				for(int x = 0; x < 4;x++)
				{
					person = PersonList[x,y];
					if(person == null)
					{
						//如果当前位置没有对象，则不需要进行任何操作
						continue;
					}
					//如果当前位置有对象，则执行以下代码
					//判断当前位置的后面是否有对象
					int destPos = -1;
					for(int y1 = y + 1; y1 < 4; y1++)
					{
						personBefore = PersonList[x,y1];
						if(personBefore!=null)
						{
                            //如果有，则不再向后找
                            if (person.name.Equals(personBefore.name))
                            {
                                //如果是相同的对象则合并，不再需要移动当前对象
                                destPos = -1;
                                Destroy(person);
                                PersonList[x, y] = null;
                                personBefore.SendMessage("UpdateLevel");
                            }
                            break;
						}else
						{
							destPos = y1;
							//如果没有则继续向后找
						}
					}
					if(destPos>-1)
					{
						//完成移动
						//1.更新矩阵信息
						PersonList[x,y] = null;
						PersonList[x,destPos] = person;
						//2.更改当前游戏对象的位置
						person.transform.position += new Vector3(0,(y-destPos)* 2.5f, 0);
					}
				}
			}
			CreatePerson();
		}else if(Input.GetKeyDown(KeyCode.LeftArrow))
		{
			for(int x = 1; x < 4; x++)
			{
				for(int y = 0; y < 4;y++)
				{
					person = PersonList[x,y];
					if(person == null)
					{
						//如果当前位置没有对象，则不需要进行任何操作
						continue;
					}
					//如果当前位置有对象，则执行以下代码
					//判断当前位置的前面是否有对象
					int destPos = -1;
					for(int x1 = x-1; x1 >= 0; x1--)
					{
						personBefore = PersonList[x1,y];
						if(personBefore!=null)
						{
                            //如果有，则不再向前找
                            if (person.name.Equals(personBefore.name))
                            {
                                //如果是相同的对象则合并，不再需要移动当前对象
                                destPos = -1;
                                Destroy(person);
                                PersonList[x, y] = null;
                                personBefore.SendMessage("UpdateLevel");
                            }
                            break;
						}else
						{
							destPos = x1;
							//如果没有则继续向前找
						}
					}
					if(destPos>-1)
					{
						//完成移动
						//1.更新矩阵信息
						PersonList[x,y] = null;
						PersonList[destPos,y] = person;
						//2.更改当前游戏对象的位置
						person.transform.position += new Vector3((destPos-x)*3f,0, 0);
					}
				}
			}
			CreatePerson();
		}else if(Input.GetKeyDown(KeyCode.RightArrow))
		{
			for(int x = 2; x >= 0 ; x--)
			{
				for(int y = 0; y < 4;y++)
				{
					person = PersonList[x,y];
					if(person == null)
					{
						//如果当前位置没有对象，则不需要进行任何操作
						continue;
					}
					//如果当前位置有对象，则执行以下代码
					//判断当前位置的前面是否有对象
					int destPos = -1;
					for(int x1 = x+1; x1 <4; x1++)
					{
						personBefore = PersonList[x1,y];
						if(personBefore!=null)
						{
                            //如果有，则不再向前找
                            if (person.name.Equals(personBefore.name))
                            {
                                //如果是相同的对象则合并，不再需要移动当前对象
                                destPos = -1;
                                Destroy(person);
                                PersonList[x, y] = null;
                                personBefore.SendMessage("UpdateLevel");
                            }
                            break;
						}else
						{
							destPos = x1;
							//如果没有则继续向前找
						}
					}
					if(destPos>-1)
					{
						//完成移动
						//1.更新矩阵信息
						PersonList[x,y] = null;
						PersonList[destPos,y] = person;
						//2.更改当前游戏对象的位置
						person.transform.position += new Vector3((destPos-x)*3f,0, 0);
					}
				}
			}
			CreatePerson();
		}

	}
    void OnGUI()
    {
        if (ItCaseHelper.IsWin)
        {
            GUI.DrawTexture(new Rect(
                (Screen.width - Win.width / 3) / 2f,
                (Screen.height - Win.height / 3) / 2f,
                Win.width / 3f,
                Win.height / 3f
                ), Win);
        }
    }
}
